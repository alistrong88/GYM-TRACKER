# Gym Program Tracker

A simple React + Vite web app to log gym sessions and view progress charts.

## Runs locally
- Install dependencies: `npm install`
- Start: `npm run dev`

## Deploy on Vercel
- Import this repo in Vercel
- Framework: Vite
- Build: `npm run build`
- Output: `dist`
